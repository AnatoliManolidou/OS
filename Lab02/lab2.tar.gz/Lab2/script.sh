#!/bin/bash

echo current_date=$(date)
echo current_time=$(date +%s)
echo let current_time=current_time*2
for i in {1..20}; do
	echo "Number: $i"
done
